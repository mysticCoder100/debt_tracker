create definer = root@localhost trigger add_wallet
    after insert
    on users
    for each row
begin
    INSERT INTO wallets(user_id) VALUES(NEW.id);
end;

