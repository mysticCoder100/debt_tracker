create definer = root@localhost trigger update_balance
    after insert
    on transactions
    for each row
begin
    DECLARE newAmount BIGINT;
    DECLARE prevAmount BIGINT;
    DECLARE type VARCHAR(8);
    DECLARE userId INT;
    
    SET type = NEW.transaction_type;
    SET userId = NEW.user_id;
    SET newAmount = NEW.amount;
    SELECT balance INTO prevAmount  FROM wallets WHERE user_id = userId;
    
    if type = 'credit' THEN
        SET prevAmount = prevAmount - newAmount;
    ELSE
        SET prevAmount = prevAmount + newAmount;
    end if;
    
    UPDATE wallets SET balance = prevAmount WHERE user_id = userId;
    
end;

